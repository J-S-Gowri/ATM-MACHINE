package com.atm_machine;

import java.util.Scanner;

public class OptionsMenu extends AccountDetails {
	AccountDetails ad=new AccountDetails();
	Scanner sc=new Scanner(System.in);
	
	public void askCustumorIDagain() {
		System.out.println("Enter the customer ID again");
		int customerID = sc.nextInt();
		System.out.println("You entered "+ customerID +"."+" Confirm your customer ID ");
		System.out.println("Enter true or false");
		boolean n = sc.nextBoolean();
		if(n==true) {
			System.out.println("Enter password");
			int passwrd = sc.nextInt();
			ad.passwordMatcher(customerID,passwrd);
		}else
			System.out.println("Okay! Try again..");
		askCustumorIDagain();	
	}
public void welcomePage() {
	System.out.println("Welcome to ATM Machine!!");
	System.out.println("Enter the customer ID");
	int customerID = sc.nextInt();
	System.out.println("You entered "+ customerID +"."+" Confirm your customer ID ");
	System.out.println("Enter true or false");
	boolean n = sc.nextBoolean();
	if(n==true) {
		System.out.println("Enter password");
		int passwrd = sc.nextInt();
		ad.passwordMatcher(customerID,passwrd);
		return;
	}else if(n==false)
		System.out.println("Okay! Try again..");
	welcomePage();
}
}
