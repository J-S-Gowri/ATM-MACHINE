package com.atm_machine;
import java.util.*;

public class AccountDetails{
	Scanner adInput= new Scanner(System.in);
	int customerID;
	int pinNUmber;
	double amount;
		
	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public int getCustomerID() {
		return customerID;
	}

	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}

	public int getPinNUmber() {
		return pinNUmber;
	}

	public void setPinNUmber(int pinNUmber) {
		this.pinNUmber = pinNUmber;
	}

	
	public void initialOptions() {
 System.out.println("Choose from the options below \n"
		+ "1 Balance Enquiry \n"
		+ "2 Deposit Amount \n"
		+ "3 Withdraw Amount \n"
		+ "4 Mini Statement \n"
		+ "5 Reset Password \n"
		+ "6 Exit");
int input = adInput.nextInt();

switch(input) {
case 1: balanceEnquiry(); 
        break;
case 2: depositeAmount(); 
        break;
case 3: withdrawAmount(); 
        break;
case 4: miniStatement(); 
        break;
case 5: resetPassword(); 
        break;
case 6: System.out.println("Thanks for visiting..! \n \n  Have a Happy Day !");
        break;        
}
	}
	
public void passwordMatcher(int customerID, int passwrd){
		
		HashMap<Integer, Integer> hm = new HashMap<Integer, Integer>();
			
			hm.put(67848, 7637);
			hm.put(97638, 9373);
			hm.put(76885, 4785);
			hm.put(44552, 4213);
			
	if(passwrd==hm.get(customerID)) {
		initialOptions();	
	} else {
		OptionsMenu mc = new OptionsMenu();
		mc.askCustumorIDagain();
	}
	}

public void balanceEnquiry() {
	System.out.println("Available balance is "+amount+".");
	initialOptions();
}

public void depositeAmount() {
	System.out.println("Enter the amount you want to deposite");
	double depoAmount=adInput.nextDouble();
	if((amount>=0||amount<0) && depoAmount>0) {
		amount = amount+depoAmount;
		System.out.println(depoAmount+" is deposited successfully."
				+ " Available balance is "+amount+".");
	}else if((amount>=0||amount<0) && depoAmount<0) {
		System.out.println("Deposite amount can not be negative.");
	}
	initialOptions();
}

public void withdrawAmount() {
	System.out.println("Enter the amount you want to withdraw");
	double withdrawAmount=adInput.nextDouble();
	if(amount>0 && (amount-withdrawAmount)>=0) {
		amount = amount-withdrawAmount;
		System.out.println(withdrawAmount+" is debited. Available balance is "+ amount+".");
	}else if(amount<0|| (amount-withdrawAmount)<0) {
		System.out.println("Insufficent fund. "+ withdrawAmount + " can not be debited.");
	}
	initialOptions();
}
 
public void miniStatement() {
	
}

public void resetPassword(){

	System.out.println("Enter old password");
	int oldPassword = adInput.nextInt();
	
}
}