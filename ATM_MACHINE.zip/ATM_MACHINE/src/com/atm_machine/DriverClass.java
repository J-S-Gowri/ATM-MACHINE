package com.atm_machine;

public class DriverClass extends OptionsMenu{

	public static void main(String[] args) {
		OptionsMenu m = new OptionsMenu();
		m.welcomePage();
	}

}
