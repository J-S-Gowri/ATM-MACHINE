module ATM_MACHINE {
}